import React from 'react';

export default function Email() {
    return (
<svg display="inline"  width="25" height="12" viewBox="0 0 25 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path id="Arrow 1" d="M25 6L15 0.226497L15 11.7735L25 6ZM2.45371e-09 7L16 7L16 5L-2.45371e-09 5L2.45371e-09 7Z" fill="#F8F5F0"/>
</svg>

    );
}
