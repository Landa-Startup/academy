import React from 'react';

export default function IconListItem() {
  return (
    <div className="self-center">
    </div>
  );
}
