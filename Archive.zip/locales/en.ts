// {
//     "aboutUs": {
//       "title": "About Us",
//       "cards": [
//         {
//           "title": "Landa Holding",
//           "text": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, diam eu tincidunt feugiat, velit elit bibendum sapien, vel bibendum sapien elit euismod diam.",
//           "link": "/StartupsForm"
//         },
//         {
//           "title": "Acceleration Center",
//           "text": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, diam eu tincidunt feugiat, velit elit bibendum sapien, vel bibendum sapien elit euismod diam.",
//           "link": "/StartupsForm"
//         },
//         {
//           "title": "Academy",
//           "text": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, diam eu tincidunt feugiat, velit elit bibendum sapien, vel bibendum sapien elit euismod diam.",
//           "link": "/academy"
//         }
//       ]
//     }
//   }


  export default {
    'hello': 'Hello',
    'hello.world': 'Hello world!',
    'welcome': 'Hello {name}!'
  } as const